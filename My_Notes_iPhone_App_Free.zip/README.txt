MY NOTES — Free iPhone App

1. इस ZIP को Windows PC में extract करें.
2. index.html, manifest.json, sw.js और icon.svg एक ही folder में रखें.
3. इसे online चलाने के लिए किसी free static hosting service पर upload करें (जैसे GitHub Pages).
4. iPhone में Safari से website खोलें.
5. Share → Add to Home Screen → Add.
6. Notes फोन के browser storage (localStorage) में save होते हैं.

महत्वपूर्ण:
- यह पहला free version है.
- App Store पर publish नहीं किया गया है.
- Basic notes/important/search/reminder data local device पर रहता है.
- iPhone पर reliable scheduled notifications के लिए बाद में native/notification service जोड़नी होगी.
